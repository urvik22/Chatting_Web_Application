-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 17, 2020 at 06:41 PM
-- Server version: 10.1.43-MariaDB-0ubuntu0.18.04.1
-- PHP Version: 7.2.26-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csvtask`
--

-- --------------------------------------------------------

--
-- Table structure for table `Details`
--

CREATE TABLE `Details` (
  `ID` int(10) NOT NULL,
  `First_Name` varchar(20) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Upload_Date` date NOT NULL,
  `Start_Date` date NOT NULL,
  `End_Date` date NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Details`
--

INSERT INTO `Details` (`ID`, `First_Name`, `Last_Name`, `Username`, `Department`, `Upload_Date`, `Start_Date`, `End_Date`, `Password`) VALUES
(1324, 'Raj ', 'Rudani', 'raj@123g.com', 'IT', '2020-03-11', '2017-07-05', '2021-08-20', '25d55ad283aa400af464c76d713c07ad'),
(1325, 'Samad ', 'Vora', 'Samad@123.com', 'CSE', '2020-03-11', '2015-01-01', '2019-05-05', '25d55ad283aa400af464c76d713c07ad'),
(1327, 'John ', 'Jac', 'John@123.com', 'Electrical', '2020-03-11', '2011-09-22', '2018-09-09', '25d55ad283aa400af464c76d713c07ad'),
(1333, 'Navik ', 'Nak', 'Nakn@123.com', 'EC', '2020-03-11', '2021-03-21', '2025-09-06', '0573bab8ef78be0c866ef674e26860c6'),
(1338, 'Urvik ', 'Patel', 'patel@123g.com', 'IT', '2020-03-11', '2016-03-05', '2020-06-03', '25d55ad283aa400af464c76d713c07ad'),
(1341, 'Dhaval ', 'Soni', 'Dhaval@123.com', 'EC', '2020-03-11', '2016-08-08', '2020-09-25', '25d55ad283aa400af464c76d713c07ad'),
(1343, 'Ram ', 'Sharma', 'Ram@123.com', 'CSE', '2020-03-11', '2014-06-25', '2017-09-09', '25d55ad283aa400af464c76d713c07ad'),
(1344, 'Radhe ', 'Sharma', 'Radhe@123.com', 'CSE', '2020-03-11', '2013-08-08', '2018-09-08', '25d55ad283aa400af464c76d713c07ad'),
(1345, 'Gyan ', 'Vatsal', 'Gyan@123.com', 'EC', '2020-03-11', '2010-09-20', '2015-04-09', '25d55ad283aa400af464c76d713c07ad'),
(1346, 'Om ', 'Prakash', 'Omprakash@123.com', 'IT', '2020-03-11', '2010-02-09', '2015-06-06', '25d55ad283aa400af464c76d713c07ad'),
(1347, 'Wood ', 'Mark', 'Wood@123.com', 'CSE', '2020-03-11', '2017-02-12', '2022-09-09', '0573bab8ef78be0c866ef674e26860c6'),
(1349, 'Nandu ', 'Prakash', 'Nandu@124.com', 'IT', '2020-03-11', '2016-05-02', '2020-08-04', '0573bab8ef78be0c866ef674e26860c6'),
(1350, 'Pain ', 'Akora', 'Akora@123.com', 'CSE', '2020-03-11', '2010-03-06', '2015-04-30', '0573bab8ef78be0c866ef674e26860c6'),
(1351, 'Aron ', 'Finch', 'Finch@1233.com', 'EC', '2020-03-11', '2012-06-12', '2017-05-22', '0573bab8ef78be0c866ef674e26860c6'),
(1352, 'David ', 'Warner', 'David@123.com', 'IT', '2020-03-11', '2013-05-22', '2018-04-25', '0573bab8ef78be0c866ef674e26860c6');

-- --------------------------------------------------------

--
-- Table structure for table `Message`
--

CREATE TABLE `Message` (
  `Id` int(100) NOT NULL,
  `Sender_Id` varchar(100) NOT NULL,
  `Receiver_Id` varchar(100) NOT NULL,
  `Message` varchar(1000) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Message`
--

INSERT INTO `Message` (`Id`, `Sender_Id`, `Receiver_Id`, `Message`, `Time`, `Status`) VALUES
(2, 'patel@123g.com', 'John@123.com', 'hello', '2020-03-12 10:20:40', ''),
(3, 'patel@123g.com', 'Dhaval@123.com', 'hello', '2020-03-12 10:59:11', 'read'),
(4, 'patel@123g.com', 'John@123.com', 'How Are You', '2020-03-12 10:59:27', ''),
(5, 'patel@123g.com', 'Dhaval@123.com', 'gfdgf', '2020-03-12 11:16:13', 'read'),
(6, 'patel@123g.com', 'Dhaval@123.com', 'hello', '2020-03-12 11:33:02', 'read'),
(7, 'patel@123g.com', 'Dhaval@123.com', 'fds', '2020-03-12 11:33:08', 'read'),
(8, 'patel@123g.com', 'Dhaval@123.com', 'good', '2020-03-12 11:33:31', 'read'),
(10, 'raj@123g.com', 'patel@123g.com', 'hiii', '2020-03-12 12:51:39', 'read'),
(11, 'patel@123g.com', 'Samad@123.com', 'hello', '2020-03-12 13:19:15', ''),
(12, 'patel@123g.com', 'Wood@123.com', 'gfdgf', '2020-03-12 13:19:33', ''),
(13, 'patel@123g.com', 'Dhaval@123.com', 'yjyj', '2020-03-13 05:37:49', 'read'),
(14, 'patel@123g.com', 'Dhaval@123.com', 'rettr', '2020-03-13 05:52:22', 'read'),
(15, 'patel@123g.com', 'Dhaval@123.com', 'vnhvbghjg', '2020-03-13 06:02:15', 'read'),
(16, 'patel@123g.com', 'Dhaval@123.com', 'fghg  yrttttttttttttttttttttttttt ytryyyyyyyyyyyyyyyyyyy hfggggggggggggggggggg  tfyhtg', '2020-03-13 06:03:41', 'read'),
(17, 'patel@123g.com', 'raj@123g.com', 'hii', '2020-03-13 06:13:25', ''),
(18, 'patel@123g.com', 'raj@123g.com', 'How Are You', '2020-03-13 06:13:38', ''),
(19, 'patel@123g.com', 'raj@123g.com', 'how are you', '2020-03-13 07:05:51', ''),
(20, 'Dhaval@123.com', 'patel@123g.com', 'hii', '2020-03-13 07:14:40', 'read'),
(21, 'Dhaval@123.com', 'patel@123g.com', 'good morning', '2020-03-13 07:14:53', 'read'),
(22, 'Dhaval@123.com', 'Samad@123.com', 'hii', '2020-03-13 07:16:31', ''),
(23, 'Dhaval@123.com', 'Samad@123.com', 'how r u', '2020-03-13 07:17:08', ''),
(24, 'Dhaval@123.com', 'patel@123g.com', 'Not Now', '2020-03-13 07:18:20', 'read'),
(25, 'patel@123g.com', 'Dhaval@123.com', 'hii', '2020-03-13 09:36:03', 'read'),
(26, 'raj@123g.com', 'patel@123g.com', 'hello', '2020-03-13 10:07:01', 'read'),
(27, 'patel@123g.com', 'raj@123g.com', 'how r u', '2020-03-13 10:07:16', ''),
(28, 'raj@123g.com', 'patel@123g.com', 'what', '2020-03-13 10:07:43', 'read'),
(29, 'patel@123g.com', 'raj@123g.com', 'how r u', '2020-03-13 10:07:50', ''),
(30, 'Samad@123.com', 'patel@123g.com', 'hello', '2020-03-13 10:24:17', 'read'),
(31, 'Samad@123.com', 'patel@123g.com', 'whats up', '2020-03-13 10:25:40', 'read'),
(32, 'patel@123g.com', 'Samad@123.com', 'nothing', '2020-03-13 10:26:10', ''),
(33, 'Samad@123.com', 'patel@123g.com', 'whats up', '2020-03-13 10:26:20', 'read'),
(34, 'Samad@123.com', 'patel@123g.com', 'ok', '2020-03-13 10:26:32', 'read'),
(35, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:26:36', ''),
(36, 'patel@123g.com', 'Samad@123.com', 'ok', '2020-03-13 10:26:48', ''),
(37, 'Samad@123.com', 'patel@123g.com', 'no problrm', '2020-03-13 10:27:14', 'read'),
(38, 'patel@123g.com', 'Samad@123.com', 'hmm', '2020-03-13 10:27:26', ''),
(39, 'Samad@123.com', 'patel@123g.com', 'hmm', '2020-03-13 10:28:01', 'read'),
(40, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:29:54', ''),
(41, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:29:57', ''),
(42, 'patel@123g.com', 'Samad@123.com', 'helllo', '2020-03-13 10:33:55', ''),
(43, 'patel@123g.com', 'Samad@123.com', 'helllo', '2020-03-13 10:34:00', ''),
(44, 'patel@123g.com', 'Samad@123.com', 'fghg', '2020-03-13 10:40:58', ''),
(45, 'patel@123g.com', 'Samad@123.com', 'rftgrtg', '2020-03-13 10:41:12', ''),
(46, 'patel@123g.com', 'Samad@123.com', 'rftgrtg', '2020-03-13 10:41:14', ''),
(47, 'patel@123g.com', 'Samad@123.com', 'rettr', '2020-03-13 10:41:30', ''),
(48, 'patel@123g.com', 'Samad@123.com', 'grttr', '2020-03-13 10:43:45', ''),
(49, 'patel@123g.com', 'Samad@123.com', 'grttr', '2020-03-13 10:43:49', ''),
(50, 'patel@123g.com', 'Samad@123.com', 'grttr', '2020-03-13 10:44:15', ''),
(51, 'patel@123g.com', 'Samad@123.com', '5tr56', '2020-03-13 10:44:23', ''),
(52, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:49:30', ''),
(53, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:49:31', ''),
(54, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:49:31', ''),
(55, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:49:32', ''),
(56, 'patel@123g.com', 'Samad@123.com', '', '2020-03-13 10:49:32', ''),
(57, 'patel@123g.com', 'Samad@123.com', 'hello', '2020-03-13 11:04:59', ''),
(58, 'patel@123g.com', 'Samad@123.com', 'hii', '2020-03-13 11:06:56', ''),
(59, 'patel@123g.com', 'Dhaval@123.com', 'hii', '2020-03-13 12:31:01', 'read'),
(60, 'patel@123g.com', 'Dhaval@123.com', 'hello', '2020-03-13 12:31:17', 'read'),
(61, 'patel@123g.com', 'John@123.com', 'msg', '2020-03-16 07:00:23', ''),
(62, 'patel@123g.com', 'John@123.com', 'msg', '2020-03-16 07:02:21', ''),
(63, 'patel@123g.com', 'John@123.com', 'sendinput', '2020-03-16 07:07:15', ''),
(64, 'patel@123g.com', 'John@123.com', 'sendinput', '2020-03-16 07:07:25', ''),
(65, 'patel@123g.com', 'John@123.com', 'sendinput', '2020-03-16 07:07:27', ''),
(66, 'patel@123g.com', 'John@123.com', 'sendinput', '2020-03-16 07:07:29', ''),
(67, 'patel@123g.com', 'John@123.com', 'sendinput', '2020-03-16 07:07:31', ''),
(68, 'patel@123g.com', 'John@123.com', 'sendinput', '2020-03-16 07:07:33', ''),
(69, 'patel@123g.com', 'John@123.com', 'sendinput', '2020-03-16 07:07:35', ''),
(70, 'patel@123g.com', 'Samad@123.com', 'hii', '2020-03-16 07:28:34', ''),
(71, 'patel@123g.com', 'John@123.com', 'koi', '2020-03-16 07:29:25', ''),
(72, 'patel@123g.com', 'John@123.com', 'koi', '2020-03-16 07:29:30', ''),
(73, 'patel@123g.com', 'John@123.com', 'koi', '2020-03-16 07:29:41', ''),
(74, 'patel@123g.com', 'Samad@123.com', 'hii', '2020-03-16 07:35:20', ''),
(75, 'patel@123g.com', 'Samad@123.com', 'hello', '2020-03-16 07:35:27', ''),
(76, 'patel@123g.com', 'Nakn@123.com', 'helllo', '2020-03-16 08:25:16', ''),
(77, 'patel@123g.com', 'Dhaval@123.com', 'rettr', '2020-03-16 08:25:23', 'read'),
(78, 'patel@123g.com', 'Dhaval@123.com', 'hrllo', '2020-03-16 08:26:46', 'read'),
(79, 'patel@123g.com', 'Dhaval@123.com', 'gfdgf', '2020-03-16 08:27:04', 'read'),
(80, 'patel@123g.com', 'Dhaval@123.com', 'gfdgf', '2020-03-16 08:27:07', 'read'),
(81, 'patel@123g.com', 'Samad@123.com', 'how', '2020-03-16 08:33:43', ''),
(82, 'patel@123g.com', 'Samad@123.com', 'helllo', '2020-03-16 08:35:11', ''),
(83, 'patel@123g.com', 'Omprakash@123.com', 'hrllo', '2020-03-16 08:36:16', ''),
(84, 'patel@123g.com', 'Omprakash@123.com', 'hii', '2020-03-16 08:36:28', ''),
(85, 'patel@123g.com', 'Omprakash@123.com', 'hii', '2020-03-16 08:47:53', ''),
(86, 'patel@123g.com', 'Omprakash@123.com', 'hello', '2020-03-16 08:50:09', ''),
(87, 'patel@123g.com', 'Omprakash@123.com', 'rettr', '2020-03-16 08:51:23', ''),
(88, 'patel@123g.com', 'Samad@123.com', ' hello', '2020-03-16 08:54:18', ''),
(89, 'patel@123g.com', 'Samad@123.com', ' how', '2020-03-16 08:54:24', ''),
(90, 'patel@123g.com', 'Samad@123.com', ' hello', '2020-03-16 08:56:39', ''),
(91, 'patel@123g.com', 'Samad@123.com', 'no', '2020-03-16 08:56:44', ''),
(93, 'patel@123g.com', 'Dhaval@123.com', 'gfdgf', '2020-03-16 09:44:31', 'read'),
(94, 'patel@123g.com', 'Dhaval@123.com', 'vnhvbghjg', '2020-03-16 09:44:35', 'read'),
(95, 'patel@123g.com', 'Dhaval@123.com', 'rettrrtrtrtr', '2020-03-16 12:53:50', 'read'),
(96, 'Dhaval@123.com', 'patel@123g.com', 'fgffgfgfgfgfgfgfgffgffgf', '2020-03-16 12:56:44', 'read'),
(97, 'patel@123g.com', 'Dhaval@123.com', 'dfgg', '2020-03-16 12:56:55', 'read'),
(98, 'patel@123g.com', 'Dhaval@123.com', 'fdffdfdddddfdd', '2020-03-16 13:10:53', 'read'),
(99, 'patel@123g.com', 'Dhaval@123.com', 'fgfgfgfggfgggfggfgfgfgfgfgfg', '2020-03-17 05:26:15', 'read'),
(100, 'Dhaval@123.com', 'patel@123g.com', 'fgfgffggfgfgfffgfgfgfgfgfgfgf', '2020-03-17 05:26:17', 'read'),
(101, 'patel@123g.com', 'Dhaval@123.com', 'ghhhghghgghghghgghhghghghhgh', '2020-03-17 05:49:51', 'read'),
(102, 'Dhaval@123.com', 'patel@123g.com', 'ghgggggghgghghghgghghgghg', '2020-03-17 05:49:55', 'read'),
(107, 'patel@123g.com', 'Nakn@123.com', 'trtvvbvvvc', '2020-03-17 06:02:53', ''),
(108, 'patel@123g.com', 'Dhaval@123.com', 'rgr', '2020-03-17 06:02:56', 'read'),
(109, 'patel@123g.com', 'Gyan@123.com', 'rettr', '2020-03-17 11:19:01', ''),
(110, 'patel@123g.com', 'Gyan@123.com', 'Not Now', '2020-03-17 11:19:09', ''),
(111, 'patel@123g.com', 'Nandu@124.com', 'ohh', '2020-03-17 11:19:25', ''),
(112, 'patel@123g.com', 'David@123.com', 'hello', '2020-03-17 11:19:39', 'read'),
(113, 'patel@123g.com', 'David@123.com', 'u6uy', '2020-03-17 11:57:14', 'read'),
(114, 'David@123.com', 'patel@123g.com', 'hello', '2020-03-17 12:06:49', 'read'),
(115, 'David@123.com', 'patel@123g.com', 'tyyt', '2020-03-17 12:10:08', 'read'),
(116, 'patel@123g.com', 'David@123.com', 'no', '2020-03-17 12:19:53', 'read'),
(117, 'patel@123g.com', 'David@123.com', 'bgrtyh', '2020-03-17 12:19:55', 'read'),
(118, 'patel@123g.com', 'David@123.com', 'tretr', '2020-03-17 12:25:44', 'read'),
(119, 'Dhaval@123.com', 'Omprakash@123.com', 'hello', '2020-03-17 12:32:39', 'unread'),
(120, 'patel@123g.com', 'Dhaval@123.com', 'dsfdf', '2020-03-17 12:35:33', 'read'),
(121, 'patel@123g.com', 'Dhaval@123.com', 'fhghg', '2020-03-17 12:35:39', 'read'),
(122, 'Dhaval@123.com', 'patel@123g.com', 'hyh', '2020-03-17 12:36:05', 'read'),
(123, 'patel@123g.com', 'Dhaval@123.com', 'frtgftg', '2020-03-17 12:54:58', 'read'),
(124, 'patel@123g.com', 'Dhaval@123.com', 'how', '2020-03-17 12:55:47', 'read'),
(125, 'Dhaval@123.com', 'patel@123g.com', 'hello', '2020-03-17 12:59:45', 'read'),
(126, 'Dhaval@123.com', 'patel@123g.com', 'how', '2020-03-17 12:59:49', 'read'),
(127, 'patel@123g.com', 'Dhaval@123.com', 'how', '2020-03-17 13:10:38', 'unread');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(10) NOT NULL,
  `sender_id` varchar(40) NOT NULL,
  `receiverid` varchar(30) NOT NULL,
  `status` enum('Yes','No') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Details`
--
ALTER TABLE `Details`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Message`
--
ALTER TABLE `Message`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Details`
--
ALTER TABLE `Details`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1353;
--
-- AUTO_INCREMENT for table `Message`
--
ALTER TABLE `Message`
  MODIFY `Id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
