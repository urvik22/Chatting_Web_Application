<?php
session_start();

class Model {

 public function getlogin()
 {
  // here goes some hardcoded values to simulate the database
 if(isset($_POST['username']) && isset($_POST['password'])){
  	    include('dbcon.php');
        $username = $_POST['username'];
		$pass = $_POST['password'];
		$_SESSION['$username'] = $username;
		$pass = md5($pass);
		 $sql = "Select * from Details where Username='$username' and Password='$pass'";
		 $result = mysqli_query($conn,$sql);
		 $row = mysqli_fetch_assoc($result);
		if($row['Username']==$username && $row['Password']==$pass){
			return 'login';
		}else{
			return 'Invalid Details';
		}
  }
 }
 public function logout()
 {
 	session_destroy();
 	header("Location:../index.php");
 } 
 public function dropdown()
 {	
 	include('dbcon.php');
 	$username = $_SESSION['$username']; 
	echo "<option selected='selected'>Select Name</option>";
	$dep_query = mysqli_query($conn,"select * from Details where Username != '$username'");
	while($row=mysqli_fetch_array($dep_query)){
		echo '<option value="'.$row['Username'].'">'.$row['First_Name']." ".$row['Last_Name']."</option>";
	}
}
public function insertmsg($senderid,$receiverid,$msg)
{
	include('dbcon.php');
	$sql = "Insert into Message (Sender_Id,Receiver_Id,Message,Status) values('$senderid','$receiverid','$msg','unread')";
	if(mysqli_query($conn,$sql)){
		
	}else{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn); 

	}

}
public function showchat()
{
	$senderid = $_SESSION['$username'];
	$receiverid = $_SESSION['$receivername'];
	include('dbcon.php');

	$sql = "Select * from Message where (Sender_Id = '$senderid' AND Receiver_Id = '$receiverid') OR (Sender_Id = '$receiverid' AND Receiver_Id = '$senderid') Order by Time ASC";
	$result = mysqli_query($conn,$sql);

	if(mysqli_num_rows($result) > 0){
		while($row = mysqli_fetch_assoc($result)) {
			$userid = '';
        	if($row['Sender_Id']==$senderid){
        		$userid = '<b>You</b>';
        	}else{
        		$userid = '<b>'.$receiverid.'</b>';
        	}
        	if($row['Message'] != ""){
        	if($userid=='<b>You</b>'){
        		if($row['Status'] == 'read'){
        		 echo "<p class='sendermsg'>".$userid.'-'.$row['Message']."
        		  		<span><b>&#2928;</b></span>
        		  	   </p>";
        		}else{
        			 echo "<p class='sendermsg'>".$userid.'-'.$row['Message']."
        		  			<span>&#10003;</span>
        		  		   </p>";

        		}
            }else{
            	echo "<p class='receivermsg'>".$userid.'-'.$row['Message']."
        		  </p>";
            }
        }
    	}
	}
	$sql1="update Message SET Status='read' where Sender_Id='$receiverid' And Receiver_Id='$senderid'";
    mysqli_query($conn,$sql1);

}
public function alluser()
{
	include('dbcon.php');
	$username = $_SESSION['$username'];
	$sql = "select * from Details where Username != '$username'";
	$query=mysqli_query($conn,$sql);
	while($row=mysqli_fetch_array($query)){
		echo "<button class='btn' name='Name' value='".$row['Username']."'>".$row['First_Name']." ".$row['Last_Name']."</button><br>";
	}
}
public function is_type($senderid,$receiverid,$is_type){
	include('dbcon.php');
	if($is_type == 'yes'){
	$sql ="insert into status(sender_id,receiverid,status) values ('$senderid','$receiverid','$is_type')";
	mysqli_query($conn,$sql);
}else{
	$sql1 = "delete from status where sender_id = '$senderid'";
	mysqli_query($conn,$sql1);
}

$qry = "select * from status where sender_id = '$receiverid' and receiverid = '$senderid'";
$result = mysqli_query($conn,$qry);
if(mysqli_num_rows($result)>0){
	echo "Typing.........";
}
}

}


?>