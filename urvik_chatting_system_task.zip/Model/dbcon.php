<?php
$conn = mysqli_connect('localhost','root','root','csvtask');
	if(!$conn){
		die('Connection Error'.mysqli_connect_error());
	}
?>