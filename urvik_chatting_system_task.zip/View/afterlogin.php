
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<style type="">
		.left{
			float: left;
			width:24%;
		}
		.right{
			float:left;
		}
		.dropdown{
			width:70%;
			height: 40px;
			font-size: 24px;
			padding-left: 24px;
			margin-left: 24px;
			margin-bottom: 30px;
			border-radius: 8px;
		}
		.chat{
			width: 50%;
			height:30px;
			border-radius: 8px;
			margin-left: 24px;
		}
	.textarea{
			  position: relative;
			  width:700px;
			  bottom: 10px;
			} 
	.textfield{
		width:100%;
		height:30px;
		border-radius: 4px;
	}
	#sendbtn{
		padding: 8px 20px;
		border-radius: 8px;
		width:30%;
	}
	.logoutbtn{
		width:50%;
		padding: 8px 20px;
		border-radius: 8px;
	}
	.Chatting_History{
		 height:473px;
		 width:100%;
		 overflow:auto;
	}
	.alluser{
		overflow-y: scroll;
		height:470px;
		 width:300px;

	}
	.btn{
		width:90%;
		padding: 8px 20px;
		font-size: 20px;
		border-radius: 8px;
	}
	.sendermsg{
		border:1px solid #ccc;
		margin-left:644px; 
		border-radius:8px;
		width:300px;
		text-align:left;
		padding:10px 0px;
		background-color: #f8e896;
	}
	.receivermsg{
		border:1px solid #ccc;
		border-radius:8px;
		width:300px;
		padding:10px 0px;
		background-color: #A8DDFD;
	}
	span {
  content: "\2713";
  float: right;
}
	@media only screen and (max-width: 767px) {
 		.left,.right{
 			width: 100%;
 		}
 		.sendermsg{
 			margin-left: 250px;
 		}
 		.alluser{
 			margin-left: 25px;
 			width:80%;
 		}
 		.textarea{
 			width:450px;
 		}
}
	</style>
</head>
<?php
require('../Controller/msgcontroller.php');
?>
<div class="left">
	<form id="showchatfrom" action="" method="POST">
		<?php
		echo "<p style='padding-left:24px;'>Message Conversion With username<br><b style='font-size:24px;'>".$_SESSION['$receivername']."</b></p>";
		?>
	<select name="Name" class="dropdown">
	 <?php  $model->dropdown(); ?>
	</select><br>
	<input type="submit" name="chat" value="Chat Now" class="chat" id="chat">
	</form>

	<div class="alluser">
		<form action="" method="POST">
			<?php $model->alluser(); ?>	
		</form>
	</div> 
</div>

<div class="right">
	<div class="Chatting_History" id="showchat">
		
		 <?php
			$model -> showchat();
		?> 
	</div>
	<div class="textarea">
		<p id="paratype"> </p> 
	<form id="msg_form" action="" method="POST" >
		<input type="text" id="msg" name="msg"  class="textfield" >
		<input type="submit" name="send" value="send" id="sendbtn">	
	</form>
	<br>
<form action="" method="POST">
	<input type="submit" name="Logout" value="Logout" class="logoutbtn">
</form>
</div>
</div>
</body>
</html>

