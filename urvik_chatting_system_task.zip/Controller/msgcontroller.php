<?php
	session_start();
	require("../Model/loginmodel.php");
	$model = new Model();
	$var = $_POST['msg'];
	echo $var;
	if(isset($_POST['Logout'])){
		$model->logout();
	}
	if((isset($_POST['chat'])) || (isset($_POST['Name']))){
		if($_POST['Name']=='Select Name'){
			$name =  "Please Select Name";
		}else{
			$name = $_POST['Name']; 
		}
		$_SESSION['$receivername'] = $name;
	}
	?>
	<script type="text/javascript">
	$(document).ready(function(){
		$( '#msg_form' ).submit(function(e){
	    var msg = $('#msg').val();
	    $.ajax({
	        url: '../Controller/ajaxcontroller.php',
	        data:{message:msg} ,
	        processData: true,
	        method: 'POST',
	        success: function ( data ) {
	            $('#showchat').html(data);
	        }
	    });
	     var msg = $('#msg').val("");
	    e.preventDefault();
		});

		$('#msg').on('focus',function(e){
			var is_type = 'yes';
		$.ajax({
			url:'../Controller/ajaxcontroller.php',
			data:{is_type1:is_type},
			processData:true,
			method:'POST',
			success:function( data ){
				$('#paratype').html(data);
			}
		});
		 e.preventDefault();
	});
		$('#msg').on('blur',function(e){
			var is_type = 'no';
		$.ajax({
			url:'../Controller/ajaxcontroller.php',
			data:{is_type1:is_type},
			processData:true,
			method:'POST',
			success:function( data ){
				$('#paratype').html(data);
			}
		});
		 e.preventDefault();
	});
	});

</script>
	