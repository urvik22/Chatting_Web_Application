<?php
	session_start();
	require("../Model/loginmodel.php");
	$model = new Model();
	$var = $_POST['message'];
	$is_type = $_POST['is_type1'];
	/*$showchat = $_POST['show'];*/
	if(!empty($var)){
		$senderid = $_SESSION['$username'];
		$receiverid = $_SESSION['$receivername'];
		if($senderid != "" && $receiverid != "Please Select Name"){
		$model->insertmsg($senderid,$receiverid,$var);
		$model->showchat($senderid,$receiverid);
		}else{
			echo "<script>alert ('please select Receiver Name')</script>";
		}
	}
	if(!empty($is_type)){
		$senderid = $_SESSION['$username'];
		$receiverid = $_SESSION['$receivername'];
		$model->is_type($senderid,$receiverid,$is_type);
	}
?>